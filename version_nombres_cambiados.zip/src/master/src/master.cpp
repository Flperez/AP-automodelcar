#include <stdio.h>
#include <stdlib.h>
#include <vector>
#include <iostream>
#include "ros/ros.h"
#include "std_msgs/MultiArrayLayout.h"
#include "std_msgs/MultiArrayDimension.h"
#include "std_msgs/Int32.h"
#include "std_msgs/Float32.h"
#include "std_msgs/Int8.h"
#include <geometry_msgs/Twist.h>
#include <math.h>

#define PI 3.1415926535897
#define Parada_Stop 2
#define Avanza 0
#define Parada_Laser 1
#define samples 10
#define Time_stop 5

using namespace std;


int quieto = 0;
int speed = 5; //(grados/seg)
int media[samples];
float errores[samples];
int k = 0;
int parada_stop = 0;
int parada_laser = 0;
int flag = 0;


class Master {
private:
	//ros::NodeHandle p,s,l,a,n;
	ros::NodeHandle p,s,l,a,n,e;
	ros::Publisher pub;
	//ros::Subscriber stop,laser,angulo;
    ros::Subscriber stop,laser,angulo,error;
	geometry_msgs::Twist velMsg;
	int estado;
	

public:
	Master();
	
	void StopCallback(const std_msgs::Int8::ConstPtr& msg);
	void laserCallback(const std_msgs::Int8::ConstPtr& msg);
	//void anguloCallback(const std_msgs::Int32::ConstPtr& msg);
	void errorCallback(const std_msgs::Float32::ConstPtr& msg);
	
	//void MaquinaEstados();


};


Master::Master():		//inicializacion de las subscripciones y publicaciones de los topicos
	
	
	estado(Avanza)
	{
		//pub = p.advertise <geometry_msgs::Twist> ("/turtle1/cmd_vel", 1);	//debug
		pub = n.advertise <geometry_msgs::Twist> ("/cmd_vel", 1);
		stop = s.subscribe("/stop",1,&Master::StopCallback,this);
		laser = l.subscribe("/laser",1,&Master::laserCallback,this);
		//angulo = a.subscribe("/angulo",1,&Master::anguloCallback,this);
        error = e.subscribe("/error",1,&Master::errorCallback,this);

	
	
	}



void Master::StopCallback(const std_msgs::Int8::ConstPtr& msg)
{


if (msg->data==1) //Se ha detectado una Señal de Stop
	{
	if (flag == 0)
		{
			flag = 1;		
			ROS_INFO("Se ha detectado un STOP");
			estado = Parada_Stop;
		}
	}

}



void Master::laserCallback(const std_msgs::Int8::ConstPtr& msg)
{

if (msg->data==1) //Se ha detectado una Señal de aproximacion del laser
	{
	estado = Parada_Laser;
	//ROS_INFO("Obstaculo cercano");
    parada_laser == 1;
	}

}



void Master::errorCallback(const std_msgs::Float32::ConstPtr& msg)
{
	
	float err = msg->data;
	double t0,t1;   

	velMsg.linear.x = 0;
	velMsg.linear.y = 0;
	velMsg.linear.z = 0;

	velMsg.angular.x = 0;
	velMsg.angular.y = 0;


	switch(estado)
	{
	case Avanza:
		printf("Estado Avanza\n");
		velMsg.angular.z = err;
		velMsg.linear.x = 0.05;
		pub.publish(velMsg);
			
	
	
	break;
	case Parada_Laser:	//parada laser
		printf("Estado parado laser\n");
		velMsg.linear.x = 0.0;
		velMsg.angular.z = 0.0;
		//ROS_INFO("FIN");
		pub.publish(velMsg); //parada indefinida


	break;
	case Parada_Stop: //parada stop
		printf("Estado parada Stop\n");
		t0 = ros::Time::now().toSec(); //tiempo inicial
		parada_stop = 0;
	    ROS_INFO("Inicio de parada por STOP");
		while(t1-t0 < Time_stop)
		{
		velMsg.linear.x = 0.0;
		velMsg.angular.z = 0.0;
		pub.publish(velMsg);
		t1 = ros::Time::now().toSec();
		}
	    ROS_INFO("Fin de parada por STOP");
		estado = 0;
 
	break;
	}
	
	
}






int main(int argc, char** argv) 
{
	
	ros::init(argc, argv, "Master");
	Master miMaster;
	ros::spin();	
	
	return 0;
}
