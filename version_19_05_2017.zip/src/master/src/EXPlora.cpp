#include "iostream"
#include <ros/ros.h>
#include <std_srvs/Trigger.h>
#include <cstdlib>
#include <ros/ros.h>
#include <actionlib/client/simple_action_client.h>
#include <nav2d_navigator/ExploreAction.h>
#include <nav2d_navigator/commands.h>

using namespace std;

#define TIMEOUT 5

typedef actionlib::SimpleActionClient<nav2d_navigator::ExploreAction> ExploreClient;

ExploreClient* gExploreClient;

class Services
{
public:
	Services();
	std_srvs::Trigger srv;
	bool metCancela(std_srvs::Trigger::Request &req, std_srvs::Trigger::Response &res);
	//bool metInicio(std_srvs::Trigger::Request &req, std_srvs::Trigger::Response &res);
	bool receiveCommand(std_srvs::Trigger::Request &req, std_srvs::Trigger::Response &res);
	void MaquinaEstados();
	void Exito();

private:
	ros::NodeHandle n,c,v,ex;
	ros::ServiceServer cancel;// start;
	ros::ServiceClient victory;
	ros::ServiceServer cmdServer;
	int estado;// connected;
	bool aborted;
	double inicio, total;
};

Services::Services():
estado(0)
{
	//start  = n.advertiseService("metodo_Inicio", &Services::metInicio, this);
	cancel = c.advertiseService("metodo_Cancela", &Services::metCancela, this);
	victory= v.serviceClient<std_srvs::Trigger>("metodo_Exito");
	cmdServer = ex.advertiseService(NAV_EXPLORE_SERVICE, &Services::receiveCommand,this);
	
	gExploreClient = new ExploreClient(NAV_EXPLORE_ACTION, true);
	
}

bool Services::receiveCommand(std_srvs::Trigger::Request &req, std_srvs::Trigger::Response &res)
{
	nav2d_navigator::ExploreGoal goal;
	gExploreClient->sendGoal(goal);
	inicio = ros::Time::now().toSec();
	while (true)
	{
		total = ros::Time::now().toSec() - inicio;
						
		if(gExploreClient->getState() == actionlib::SimpleClientGoalState::SUCCEEDED)
		{
			Exito();
			ROS_INFO("Objetivo conseguido");
			estado = 1;
			res.success = true;
			return true;	
		}

		if(aborted == true)
		{
			ROS_WARN("Exploracion abortada");
			estado = 2;
			return true;
			
		}		
	
		if(total >= TIMEOUT)
		{
			
			gExploreClient->cancelAllGoals();
			ROS_ERROR("Demasiado tiempo realizando la exploracion");
			return false;
		}
	ros::spinOnce();	
	}	
}

bool Services::metCancela(std_srvs::Trigger::Request &req, std_srvs::Trigger::Response &res)
{
	gExploreClient->cancelAllGoals();
	aborted = true;
	res.success = true;
	res.message = "Cancelada";
	return true;
}

void Services::Exito()
{
	if(victory.call(srv))
	{

	}
}

void Services::MaquinaEstados()
{
	while(ros::ok())
	{
		switch(estado)
		{
			case 0:
				gExploreClient->waitForServer();
				break;

			case 1: 
				ROS_INFO("Exploracion terminada");
				estado = 0;
				break;
			
			case 2: 
				ROS_INFO("Cancelada");
				estado = 0;
				break;

		}
	ros::spinOnce();	
	}
}


int main(int argc, char **argv)
{
	ros::init(argc, argv, "Nodo_Explora");
	ROS_INFO("Se inicio el nodo explora");
	Services servicios;
	servicios.MaquinaEstados();

	delete gExploreClient;

}
