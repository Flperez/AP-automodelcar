#!/usr/bin/env python
from __future__ import print_function
import roslib
roslib.load_manifest('prueba')
import sys
import rospy
import cv2
from std_msgs.msg import String
from sensor_msgs.msg import Image
from cv_bridge import CvBridge, CvBridgeError
import numpy as np

min_size      = (10, 10)
image_scale   = 2
haar_scale    = 1.2
min_neighbors = 2
haar_flags    = 0

stop_cascade = cv2.CascadeClassifier('../haar/stop_cascade.xml')

class image_converter:


  def __init__(self):
    self.image_pub = rospy.Publisher("usb_cam/image_processed",Image, queue_size=10)
    self.bridge = CvBridge()
    self.image_sub = rospy.Subscriber("/mybot/camera1/image_raw",Image,self.callback)
    self.object_pub = rospy.Publisher('chatter', String, queue_size=10)
	
    

  def callback(self,data):
    try:
      img = self.bridge.imgmsg_to_cv2(data, "bgr8")
    except CvBridgeError as e:
      print(e)
	
    #pub = rospy.Publisher('chatter', String, queue_size=10)
    rate = rospy.Rate(10) # 10hz
    
    hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)
	
    #red bajo y alto
    
    rojo_bajos1 = np.array([0,65,75], dtype=np.uint8)
    rojo_altos1 = np.array([12, 255, 255], dtype=np.uint8)
    rojo_bajos2 = np.array([240,65,75], dtype=np.uint8)
    rojo_altos2 = np.array([256, 255, 255], dtype=np.uint8)
    
    #hsv_red_alto = cv2.cvtColor(rojo_altos1,cv2.COLOR_BGR2HSV)
    #hsv_red_bajo = cv2.cvtColor(rojo_bajos1,cv2.COLOR_BGR2HSV)
    mascara_rojo1 = cv2.inRange(hsv, rojo_bajos1, rojo_altos1)
    mascara_rojo2 = cv2.inRange(hsv, rojo_bajos2, rojo_altos2)
   
    #Guardamos el rango de colores hsv (azules)
    #bajos = np.array(hsv_red_alto, dtype=np.uint8)
    #altos = np.array(hsv_red_bajo, dtype=np.uint8)
       
    #Crear una mascara que detecte los colores
    mask = cv2.add(mascara_rojo1, mascara_rojo2)
	
	#Filtrar el ruido con un CLOSE seguido de un OPEN
    kernel = np.ones((6,6),np.uint8)
    mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, kernel)
    mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, kernel)
       
    #Difuminamos la mascara para suavizar los contornos y aplicamos filtro canny
    blur = cv2.GaussianBlur(mask, (5, 5), 0)
    edges = cv2.Canny(mask,1,2)
       
    #Si el area blanca de la mascara es superior a 500px, no se trata de ruido
    contours, hier = cv2.findContours(edges,cv2.RETR_TREE,cv2.CHAIN_APPROX_SIMPLE)
    areas = [cv2.contourArea(c) for c in contours]
    
    cv2.imshow('mask', mask)
    cv2.imshow('Camara', img)

    #cv2.imshow("result", img)
    cv2.waitKey(3)

    try:
      self.image_pub.publish(self.bridge.cv2_to_imgmsg(img, "bgr8"))
      #self.object_pub.publish(string)
    except CvBridgeError as e:
      print(e)

def main(args):
  

  rospy.init_node('image_converter', anonymous=True)
  ic = image_converter()
  try:
    rospy.spin()
  except KeyboardInterrupt:
    print("Shutting down")
  cv2.destroyAllWindows()

if __name__ == '__main__':
    main(sys.argv)
