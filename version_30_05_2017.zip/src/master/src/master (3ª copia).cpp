#include <stdio.h>
#include <stdlib.h>
#include <vector>
#include <iostream>
#include "ros/ros.h"
#include "std_msgs/MultiArrayLayout.h"
#include "std_msgs/MultiArrayDimension.h"
#include "std_msgs/Int32.h"
#include "std_msgs/Int8.h"
#include <geometry_msgs/Twist.h>
#include <math.h>

#define PI 3.1415926535897
#define Parado 1
#define Avanza 2
#define samples 50

using namespace std;


int quieto = 0;
int speed = 5; //(grados/seg)
int media[samples];
int k = 0;

class Master {
private:
	ros::NodeHandle p,s,l,a,n;
	ros::Publisher pub;
	ros::Subscriber stop,laser,angulo;
	geometry_msgs::Twist velMsg;
	int estado;
	

public:
	Master();
	
	void StopCallback(const std_msgs::Int8::ConstPtr& msg);
	void laserCallback(const std_msgs::Int8::ConstPtr& msg);
	void anguloCallback(const std_msgs::Int32::ConstPtr& msg);
	
	//void MaquinaEstados();


};


Master::Master():		//inicializacion de las subscripciones y publicaciones de los topicos
	
	estado(0)
	/*velMsg.linear.x(0)
	velMsg.linear.y(0)
	velMsg.linear.z (0)
	velMsg.angular.x (0)
	velMsg.angular.y (0)
	velMsg.angular.z (0)*/
	{
		//pub = p.advertise <geometry_msgs::Twist> ("/turtle1/cmd_vel", 1);	
		pub = n.advertise <geometry_msgs::Twist> ("/cmd_vel", 1);
		stop = s.subscribe("/stop",1,&Master::StopCallback,this);
		laser = l.subscribe("/laser",1,&Master::laserCallback,this);
		angulo = a.subscribe("/angulo",1,&Master::anguloCallback,this);

	
	
	}



void Master::StopCallback(const std_msgs::Int8::ConstPtr& msg)
{


if (msg->data==1) //Se ha detectado una Señal de Stop
	{
	
	ROS_INFO("Se ha detectado una señal de STOP");
	}

}



void Master::laserCallback(const std_msgs::Int8::ConstPtr& msg)
{

if (msg->data==1) //Se ha detectado una Señal de aproximacion del laser
	{
	estado = Parado;
	ROS_INFO("Obstaculo cercano");
	}
else
	{
	estado = Avanza;		
	}
}

void Master::anguloCallback(const std_msgs::Int32::ConstPtr& msg)
{
	
	int angle = msg->data;
	int aux = 0;
	int i = 0;
	int flag = 0;
	float angular_speed = 0.01;
	//speed*2*PI/360;//rad/s
    int relative_angle; 
	media[k] = angle;
		k++;

	velMsg.linear.x = 0;
	velMsg.linear.y = 0;
	velMsg.linear.z = 0;

	velMsg.angular.x = 0;
	velMsg.angular.y = 0;
		
		if (k==samples) //se ha rellenado
		{
			for (i=0;i<samples;i++)
				{
					//printf("%d \n",angle);
					aux=aux+media[i];
				}aux = aux/samples;
			printf("Media: %d\n",aux);		
			k = 0;
			/*Escribe aqui*/
			
			

			if (aux>-8 && aux<=0 || aux>=-180 &&	aux<-172)
			{
				printf("linea recta \n");
				velMsg.angular.z = 0;
				velMsg.linear.x = 0.04;
				flag = 1;
			} 
			else if (aux<0 && aux>-90) 
			{ // turn right
				printf("Derecha\n");
				velMsg.angular.z = angular_speed;
				relative_angle = abs(aux);
				if (flag==1)
			{velMsg.linear.x = 0.04;}
														
			}
			else if (aux >= -180 && aux<-90) 
			{ // turn left
				printf("Izquierda\n");
				velMsg.angular.z = -angular_speed;
				relative_angle = (aux)+180; 
				if (flag==1)
				{velMsg.linear.x = 0.04;}
			}
			
			

			



			pub.publish(velMsg);
			
			
		}

}
/*
void Master::MaquinaEstados()
{
	while(ros::ok())
	{
		switch(estado)
		{
			case 0:
				
				break;

			case Parado: //Parado
				
				break;
			
			case Avanza: 
				
				break;

		}
	ros::spinOnce();	
	}
}
*/




int main(int argc, char** argv) 
{
	
	ros::init(argc, argv, "Master");
	Master miMaster;
	ros::spin();	
	
	return 0;
}
