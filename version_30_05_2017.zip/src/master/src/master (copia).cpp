#include <stdio.h>
#include <stdlib.h>
#include <vector>
#include <iostream>
#include "ros/ros.h"
#include "std_msgs/MultiArrayLayout.h"
#include "std_msgs/MultiArrayDimension.h"
#include "std_msgs/Int32.h"
#include "std_msgs/Int8.h"
#include <geometry_msgs/Twist.h>
#include <math.h>

#define PI 3.1415926535897
#define Parado 1
#define Avanza 2
#define samples 50

using namespace std;
int flag = 0;
int media[samples];
int k = 0;

int quieto = 0;
int speed = 30; //(grados/seg)


class Master {
private:
	ros::NodeHandle p,s,l,a;
	ros::Publisher pub;
	ros::Subscriber stop,laser,angulo;
	geometry_msgs::Twist velMsg;
	int estado;
	

public:
	Master();
	
	void StopCallback(const std_msgs::Int8::ConstPtr& msg);
	void laserCallback(const std_msgs::Int8::ConstPtr& msg);
	void anguloCallback(const std_msgs::Int32::ConstPtr& msg);
	
	//void MaquinaEstados();


};


Master::Master():		//inicializacion de las subscripciones y publicaciones de los topicos
	
	estado(0)
	/*velMsg.linear.x(0)
	velMsg.linear.y(0)
	velMsg.linear.z (0)
	velMsg.angular.x (0)
	velMsg.angular.y (0)
	velMsg.angular.z (0)*/
	{
		pub = p.advertise <geometry_msgs::Twist> ("/turtle1/cmd_vel", 1);	
		//pub = n.advertise <geometry_msgs::Twist> ("/cmd_vel", 1);
		stop = s.subscribe("/stop",1,&Master::StopCallback,this);
		laser = l.subscribe("/laser",1,&Master::laserCallback,this);
		angulo = a.subscribe("/angulo",1,&Master::anguloCallback,this);

	
	
	}



void Master::StopCallback(const std_msgs::Int8::ConstPtr& msg)
{


if (msg->data==1) //Se ha detectado una Señal de Stop
	{
	
	ROS_INFO("Se ha detectado una señal de STOP");
	}

}



void Master::laserCallback(const std_msgs::Int8::ConstPtr& msg)
{

if (msg->data==1) //Se ha detectado una Señal de aproximacion del laser
	{
	estado = Parado;
	ROS_INFO("Obstaculo cercano");
	}
else
	{
	estado = Avanza;		
	}
}

void Master::anguloCallback(const std_msgs::Int32::ConstPtr& msg)
{
	//while(ros::ok){
	int angle = msg->data;
	int aux = 0;
	int i = 0;
	
		media[k] = angle;
		k++;
		
		if (k==samples) //se ha rellenado
		{
			for (i=0;i<samples;i++)
				{
					//printf("%d \n",angle);
					aux=aux+media[i];
				}aux = aux/samples;
			printf("Media: %d\n",aux);		
			k = 0;		
		}
			
	
	

	
		int angular_speed = speed*2*PI/360;//rad/s
    int relative_angle = abs(angle*PI/180-PI/2);//rad/s
	
	
	if (angle >= 90)  // giro a la izquierda 
	{velMsg.angular.z = angular_speed;}
	else			//giro a la derecha
	{velMsg.angular.z = -angular_speed;}
	
	velMsg.linear.x = 0;
	velMsg.linear.y = 0;
	velMsg.linear.z = 0;

	velMsg.angular.x = 0;
	velMsg.angular.y = 0;
	

	double t0 = ros::Time::now().toSec();
	int current_angle = 0;
	
	while(current_angle < relative_angle)
	{
		//pub.publish(velMsg);
		double t1 = ros::Time::now().toSec();
		current_angle = angular_speed*(t1-t0);
	
	}
	
	velMsg.angular.z = 0;
	//	pub.publish(velMsg);
	
//}



}

/*void Master::MaquinaEstados()
{
	while(ros::ok())
	{
		switch(estado)
		{
			case 0:
				
				
				break;

			case Parado: //Parado
				
				break;
			
			case Avanza: 
				
				break;

		}
	//ros::spin();	
	}
}*/





int main(int argc, char** argv) {
	
	ros::init(argc, argv, "Master");
	Master miMaster;
	ros::spin();	
	
	return 0;
}
