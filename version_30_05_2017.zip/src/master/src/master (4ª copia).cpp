#include <stdio.h>
#include <stdlib.h>
#include <vector>
#include <iostream>
#include "ros/ros.h"
#include "std_msgs/MultiArrayLayout.h"
#include "std_msgs/MultiArrayDimension.h"
#include "std_msgs/Int32.h"
#include "std_msgs/Float32.h"
#include "std_msgs/Int8.h"
#include <geometry_msgs/Twist.h>
#include <math.h>

#define PI 3.1415926535897
#define Parado 1
#define Avanza 2
#define samples 10
#define Time_stop 5

using namespace std;


int quieto = 0;
int speed = 5; //(grados/seg)
int media[samples];
int errores[samples];
int k = 0;
int parada_stop = 0;
int parada_laser = 0;
int flag = 0;

class Master {
private:
	ros::NodeHandle p,s,l,a,n;
	//ros::NodeHandle p,s,l,a,n,e;
	ros::Publisher pub;
	ros::Subscriber stop,laser,angulo;
    //ros::Subscriber stop,laser,angulo,error;
	geometry_msgs::Twist velMsg;
	int estado;
	

public:
	Master();
	
	void StopCallback(const std_msgs::Int8::ConstPtr& msg);
	void laserCallback(const std_msgs::Int8::ConstPtr& msg);
	void anguloCallback(const std_msgs::Int32::ConstPtr& msg);
	//void errorCallback(const std_msgs::Float32::ConstPtr& msg)
	
	//void MaquinaEstados();


};


Master::Master():		//inicializacion de las subscripciones y publicaciones de los topicos
	
	
	estado(0)
	{
		//pub = p.advertise <geometry_msgs::Twist> ("/turtle1/cmd_vel", 1);	//debug
		pub = n.advertise <geometry_msgs::Twist> ("/cmd_vel", 1);
		stop = s.subscribe("/stop",1,&Master::StopCallback,this);
		laser = l.subscribe("/laser",1,&Master::laserCallback,this);
		angulo = a.subscribe("/angulo",1,&Master::anguloCallback,this);
        //error = e.subscribe("/error",1,&Master::errorCallback,this);

	
	
	}



void Master::StopCallback(const std_msgs::Int8::ConstPtr& msg)
{


if (msg->data==1) //Se ha detectado una Señal de Stop
	{
	if (flag == 0)
		{
			flag = 1;		
			ROS_INFO("Se ha detectado un STOP");
			parada_stop = 1;
		}
	}

}



void Master::laserCallback(const std_msgs::Int8::ConstPtr& msg)
{

if (msg->data==1) //Se ha detectado una Señal de aproximacion del laser
	{
	estado = Parado;
	ROS_INFO("Obstaculo cercano");
    parada_laser == 1;
	}
else
	{
	estado = Avanza;
    parada_laser == 0;		
	}
}

void Master::anguloCallback(const std_msgs::Int32::ConstPtr& msg)
{
	
	int angle = msg->data;
	int aux = 0;
	int i = 0;
	double t0,t1;
	float angular_speed = 0.01/2;
	//speed*2*PI/360;//rad/s
    int relative_angle; 
	media[k] = angle;
	k++;

	velMsg.linear.x = 0;
	velMsg.linear.y = 0;
	velMsg.linear.z = 0;

	velMsg.angular.x = 0;
	velMsg.angular.y = 0;

	if (parada_stop == 1)
	{
		t0 = ros::Time::now().toSec(); //tiempo inicial
		parada_stop = 0;
	    ROS_INFO("Inicio de parada por STOP");
		while(t1-t0 < Time_stop)
		{
		velMsg.linear.x = 0.0;
		velMsg.angular.z = 0.0;
		pub.publish(velMsg);
		t1 = ros::Time::now().toSec();
		}
	    ROS_INFO("Fin de parada por STOP");


	}

	if (parada_laser == 1)
	{
		velMsg.linear.x = 0.0;
		velMsg.angular.z = 0.0;
		ROS_INFO("FIN");
		pub.publish(velMsg); //parada indefinida
	}
		
		if (k==samples) //se ha rellenado
		{
			for (i=0;i<samples;i++)
				{
					//printf("%d \n",angle);
					aux=aux+media[i];
				}aux = aux/samples;
			printf("Media: %d\n",aux);		
			k = 0;
			/*Escribe aqui*/
			
			 
			
			if (aux>-8 && aux<=0 || aux>=-180 &&	aux<-172)
			{
				printf("linea recta \n");
				velMsg.angular.z = 0;
				velMsg.linear.x = 0.04;

			} 
			else if (aux<0 && aux>-90) 
			{ // turn right
				printf("Derecha\n");
				velMsg.angular.z = angular_speed;
				relative_angle = abs(aux);
				
			{velMsg.linear.x = 0.02;}
														
			}
			else if (aux >= -180 && aux<-90) 
			{ // turn left
				printf("Izquierda\n");
				velMsg.angular.z = -angular_speed;
				relative_angle = (aux)+180; 
				
				{velMsg.linear.x = 0.02;}
			}
			
			

			pub.publish(velMsg);
			
			
		}

}


/*


void Master::errorCallback(const std_msgs::Float32::ConstPtr& msg)
{
	
	int err = msg->data;
	int media = 0;
	int i = 0;
	double t0,t1;
	float angular_speed = 0.01/2;
	//speed*2*PI/360;//rad/s
    int relative_angle; 
	errores[k] = err;
	k++;

	velMsg.linear.x = 0;
	velMsg.linear.y = 0;
	velMsg.linear.z = 0;

	velMsg.angular.x = 0;
	velMsg.angular.y = 0;

	if (parada_stop == 1)
	{
		t0 = ros::Time::now().toSec(); //tiempo inicial
		parada_stop = 0;
	    ROS_INFO("Inicio de parada por STOP");
		while(t1-t0 < Timeout)
		{
		velMsg.linear.x = 0.0;
		velMsg.angular.z = 0.0;
		pub.publish(velMsg);
		t1 = ros::Time::now().toSec();
		}
	    ROS_INFO("Fin de parada por STOP");


	}

	if (parada_laser == 1)
	{
		velMsg.linear.x = 0.0;
		velMsg.angular.z = 0.0;
		ROS_INFO("FIN");
		pub.publish(velMsg); //parada indefinida
	}
		
		if (k==samples) //se ha rellenado
		{
			for (i=0;i<samples;i++)
				{
					//printf("%d \n",angle);
					media=media+errores[i];
				}media = media/samples;
			printf("Media: %d\n",media);		
			k = 0;
			
			velMsg.angular.z = media;
			velMsg.linear.x = 0.05;
			
			
			pub.publish(velMsg);
			
			
		}

}

*/



int main(int argc, char** argv) 
{
	
	ros::init(argc, argv, "Master");
	Master miMaster;
	ros::spin();	
	
	return 0;
}
