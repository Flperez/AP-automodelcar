#include "ros/ros.h"
#include "tf/transform_listener.h"
#include "sensor_msgs/PointCloud.h"
#include "sensor_msgs/LaserScan.h"
#include "tf/message_filter.h"
#include "message_filters/subscriber.h"
#include "laser_geometry/laser_geometry.h"
#include "std_msgs/Int8.h"

#define distancia 1.5 //ejemplo
class LaserScan{

private:

	ros::NodeHandle n,p;
	ros::Subscriber scanSub;
	ros::Publisher pub;
	std_msgs::Int8 detectado;

public:
	LaserScan();
	
	void LaserScanCallback(const sensor_msgs::LaserScan::ConstPtr& scan);

};

LaserScan::LaserScan()
{
	//Suscrito a /mybot/laser/scan
	scanSub = n.subscribe<sensor_msgs::LaserScan>("/mybot/laser/scan",100,&LaserScan::LaserScanCallback,this);
	//se publica en /laser como int8
	pub = p.advertise <std_msgs::Int8> ("/laser", 100);


}

void LaserScan::LaserScanCallback(const sensor_msgs::LaserScan::ConstPtr& scan)

{
//scan->ranges[] are laser readings
/*
Informacion del laser
header: 
  seq: 2468
  stamp: 
    secs: 256
    nsecs: 420000000
  frame_id: hokuyo
angle_min: -0.77999997139
angle_max: 0.77999997139
angle_increment: 0.00871508382261
time_increment: 0.0
scan_time: 0.0
range_min: 0.10000000149
range_max: 5.0
ranges: [....]
intesities: [...]




*/
int i;

//719=(angle_max-angle_min)/angle_increment;
for (i=0;i<180;i++)
{
	
	if (scan->ranges[i] < distancia)
	{//Publica un "1" en /laser
		detectado.data = 1;
		printf("%f\n",scan->ranges[i]);
		//detectado.data = scan->ranges[i]
		pub.publish(detectado);
		ROS_INFO("Se ha detectado un obstaculo");
	}
}




}





int main(int argc, char** argv)
{
  //inicializacion del nodo de laser
  ros::init(argc, argv, "Mi_laser");
  //inicializamos la clase de Laser
  LaserScan Milaser;
  //ros::spin() --> se ejecute siempre
  ros::spin();
  
  return 0;
}
