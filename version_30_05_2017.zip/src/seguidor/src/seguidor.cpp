
namespace cv_bridge {

class CvImage
{
public:
  std_msgs::Header header;
  std::string encoding;
  cv::Mat image;
};

typedef boost::shared_ptr<CvImage> CvImagePtr;
typedef boost::shared_ptr<CvImage const> CvImageConstPtr;

}



void image_callback(self, msg) // faltan los argumentos bien 
{
    image=cv_bridge::toCvCopy(msg, sensor_msgs::image_encodings::BGR8); // transforma msg ros a imagen opencv
	cvtColor(image, hsv, cv::COLOR_BGR2HSV); // bgr to hsv
	inRange(hsv,Scalar(0, 0, 200), Scalar(180,20,255),mask); // rango de colores
    
	w=image.size().width;
	h=image.size().height;
    
    search_top=3*h/4;
    search_bot=3*h/4 + 20;
	
	int i,j;
	for (i=0; i==search_top; i++) {
		for (j=0; j==w; j++) {
			mask[i][j]=0;
		}
	}
	for (i=search_bot; i==h; i++){
		for (j=0; j==w; j++) {
			mask[i][j]=0;
		}
	}
   
    m=cv::moments(mask);
	
	if(m.m00>0){
		cx=int(m.m10/m.m00);
		cy=int(m.m01/m.m00);
		circle( image, Point( cx, cy ), 20, Scalar( 0, 0, 255 ), -1 ); // pinta el punto a seguir
		// comienza el control
		err=cx-(w/2);
		
		/*
		Esta parte es de mensajes de ros para el control
		self.twist.linear.x = 0.2
		self.twist.angular.z = -float(err) / 100
		self.cmd_vel_pub.publish(self.twist)*/	
	
	}
	/*
	Y esto supongo que no hace falta aqu�
    cv2.imshow("window", image)
    cv2.waitKey(3)*/
	
}