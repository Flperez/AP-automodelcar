#!/usr/bin/env python
import sys
import rospy
import cv2
from std_msgs.msg import String
from sensor_msgs.msg import Image
from cv_bridge import CvBridge, CvBridgeError
import numpy
from geometry_msgs.msg import Twist
from std_msgs.msg import Float32

class image_converter:

  def __init__(self):


    self.bridge = CvBridge()
    self.image_sub = rospy.Subscriber("/mybot/camera1/image_raw",Image,self.callback)
    self.cmd_vel_pub = rospy.Publisher('/cmd_vel',
                                       Twist, queue_size=100)
    self.error_pub = rospy.Publisher('/error',
                                       Float32, queue_size=100)
    self.twist = Twist()

  def callback(self,data):
    try:
      image = self.bridge.imgmsg_to_cv2(data, "bgr8")
    except CvBridgeError as e:
      print(e)
    
    (h, w, d) = image.shape
    image_copy = image
    image_copy[h/2-20:h,0:w]=0
    
#    hsv = cv2.cvtColor(image, cv2.COLOR_BGR2HSV)
    hsv = cv2.cvtColor(image_copy, cv2.COLOR_BGR2HSV)
    lower_yellow = numpy.array([ 0,  0,  172])
    upper_yellow = numpy.array([180, 97, 255])
    
    mask = cv2.inRange(hsv, lower_yellow, upper_yellow)
    ret,thresh = cv2.threshold(image,127,255,0)
    #ret,contours,hierarchy = cv2.findContours(thresh, 1, 2)
    #cnt = contours[0]

    kernel = numpy.ones((6,6),numpy.uint8)
    mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, kernel)
    mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, kernel)

    #Difuminamos la mascara para suavizar los contornos 
    blur = cv2.GaussianBlur(mask, (5, 5), 0)

       
    
	
    
    

    search_top = 3*h/4
    search_bot = 3*h/4 + 20

    #mask[0:search_top, 0:w] = 0
    #mask[search_bot:h, 0:w] = 0
    M = cv2.moments(mask)   
    
    if M['m00'] > 0:
      cx = int(M['m10']/M['m00'])
      cy = int(M['m01']/M['m00'])
     
      cv2.circle(image, (cx, cy), 10, (0,0,255), -1)
      #cv2.line(image,(cx,cy),(w/2,cy),(0,255,0),1,8,0)
      # BEGIN CONTROL
      err = cx - w/2 
      envio = (float (err) / 1000) * 0.5
      print ('envio: ',envio)
      
      self.error_pub.publish(envio)
      #self.twist.linear.x = 0.05
      #self.twist.angular.z = (float(err) / 1000) * 0.1
      #self.cmd_vel_pub.publish(self.twist)
      # END CONTROL

    cv2.imshow("Image window", image_copy)
    #cv2.imshow("mask", mask)

    cv2.waitKey(3)

  

def main(args):
  ic = image_converter()
  rospy.init_node('image_converter', anonymous=True)
  try:
    rospy.spin()
  except KeyboardInterrupt:
    print("Shutting down")
  cv2.destroyAllWindows()

if __name__ == '__main__':
    main(sys.argv)








